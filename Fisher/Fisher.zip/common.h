/* 
 * File:   common.h
 * Author: ricepig
 *
 */

#ifndef COMMON_H
#define	COMMON_H

void print_error(char * msg)
{
    printf("[ERROR] %s\n", msg);
}

#endif	/* COMMON_H */

